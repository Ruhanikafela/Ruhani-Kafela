/* =========================================================
   Language toggle — Bengali (default) / English
   Persists choice in localStorage as "rk_lang"
   ========================================================= */
(function(){
  const STORAGE_KEY = 'rk_lang';
  const DEFAULT_LANG = 'bn';

  function getSavedLang(){
    try{
      return localStorage.getItem(STORAGE_KEY) || DEFAULT_LANG;
    }catch(e){
      return DEFAULT_LANG;
    }
  }

  function setLang(lang){
    document.documentElement.setAttribute('data-lang', lang);
    document.documentElement.setAttribute('lang', lang === 'bn' ? 'bn' : 'en');
    try{ localStorage.setItem(STORAGE_KEY, lang); }catch(e){}

    document.querySelectorAll('.lang-toggle button').forEach(function(btn){
      btn.classList.toggle('active', btn.dataset.lang === lang);
    });
  }

  function initLangToggle(){
    document.querySelectorAll('.lang-toggle button').forEach(function(btn){
      btn.addEventListener('click', function(){
        setLang(btn.dataset.lang);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    setLang(getSavedLang());
    initLangToggle();
  });

  // Expose for other scripts (e.g. app.js rendering dummy content in the right language)
  window.RK_LANG = { get: getSavedLang, set: setLang };
})();
