/* =========================================================
   App logic — Phase 1
   Renders homepage sections from local dummy data.
   In Phase 2, each render function below will be fed by
   js/api.js instead of the DUMMY_* arrays — the render
   functions and card markup will not need to change.
   ========================================================= */

/* ---------- Mobile nav ---------- */
document.addEventListener('DOMContentLoaded', function(){
  const hamburger = document.querySelector('.hamburger');
  const nav = document.querySelector('.main-nav');
  if(hamburger && nav){
    hamburger.addEventListener('click', function(){
      nav.classList.toggle('open');
    });
    nav.querySelectorAll('a').forEach(function(a){
      a.addEventListener('click', function(){ nav.classList.remove('open'); });
    });
  }
});

/* ---------- Dummy content (Phase 1 placeholder data) ---------- */

const DUMMY_ARTICLES = [
  {
    titleBn: 'নিয়তের গুরুত্ব ও আত্মশুদ্ধির প্রথম ধাপ',
    titleEn: 'The Importance of Niyyah: The First Step of Self-Purification',
    excerptBn: 'প্রতিটি আমলের ফলাফল নির্ভর করে অন্তরের নিয়তের ওপর। এই লেখায় নিয়ত শুদ্ধ করার প্রাথমিক পথ নিয়ে আলোচনা।',
    excerptEn: 'Every act is judged by the intention behind it. A short reflection on purifying the heart\u2019s intention.',
    category: 'ইলম ও পাঠ',
    categoryEn: 'Knowledge & Reading',
    date: '১২ সেপ্টেম্বর, ২০২৬'
  },
  {
    titleBn: 'রমজানের শেষ দশকে বিশেষ আমল',
    titleEn: 'Special Practices in the Last Ten Nights of Ramadan',
    excerptBn: 'রমজানের শেষ দশকে যেসব আমল ও দোয়ার প্রতি বিশেষ গুরুত্ব দেওয়া হয়েছে তার একটি সংক্ষিপ্ত পরিচিতি।',
    excerptEn: 'A brief guide to the practices emphasized in the final ten nights of Ramadan.',
    category: 'দোয়া ও আমল',
    categoryEn: 'Dua & Amal',
    date: '৩ সেপ্টেম্বর, ২০২৬'
  },
  {
    titleBn: 'মুরাকাবার প্রাথমিক পরিচিতি',
    titleEn: 'An Introduction to Muraqabah (Spiritual Meditation)',
    excerptBn: 'মুরাকাবা কী, এর উদ্দেশ্য এবং একজন নতুন অনুশীলনকারীর জন্য প্রাথমিক করণীয়।',
    excerptEn: 'What Muraqabah is, its purpose, and first steps for a new practitioner.',
    category: 'জিকির ও ধ্যান',
    categoryEn: 'Zikr & Meditation',
    date: '২৮ আগস্ট, ২০২৬'
  }
];

const DUMMY_ZIKR = [
  { arabic:'سُبْحَانَ اللّٰهِ', titleBn:'সুবহানাল্লাহ', titleEn:'SubhanAllah', countBn:'৩৩ বার', countEn:'33 times' },
  { arabic:'اَلْحَمْدُ لِلّٰهِ', titleBn:'আলহামদুলিল্লাহ', titleEn:'Alhamdulillah', countBn:'৩৩ বার', countEn:'33 times' },
  { arabic:'اَللّٰهُ أَكْبَرُ', titleBn:'আল্লাহু আকবার', titleEn:'Allahu Akbar', countBn:'৩৪ বার', countEn:'34 times' }
];

const DUMMY_DUA = [
  { arabic:'رَبِّ زِدْنِي عِلْمًا', titleBn:'জ্ঞান বৃদ্ধির দোয়া', titleEn:'Dua for Increase in Knowledge', occasionBn:'দৈনিক', occasionEn:'Daily' },
  { arabic:'رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً', titleBn:'দুনিয়া ও আখিরাতের কল্যাণের দোয়া', titleEn:'Dua for Good in This World and the Next', occasionBn:'সাধারণ', occasionEn:'General' }
];

const DUMMY_BOOKS = [
  { titleBn:'আত্মশুদ্ধির পথ', titleEn:'The Path of Self-Purification', author:'সংকলিত' },
  { titleBn:'জিকিরের ফযিলত', titleEn:'The Virtues of Remembrance', author:'সংকলিত' },
  { titleBn:'মুরাকাবা ও তাসাউফ পরিচিতি', titleEn:'An Introduction to Muraqabah & Tasawwuf', author:'সংকলিত' }
];

const DUMMY_COURSES = [
  { titleBn:'তাসাউফের প্রাথমিক পাঠ', titleEn:'Foundations of Tasawwuf', instructor:'উস্তাদ প্যানেল', durationBn:'৬ সপ্তাহ', durationEn:'6 weeks', type:'free' },
  { titleBn:'জিকির ও মুরাকাবা কর্মশালা', titleEn:'Zikr & Muraqabah Workshop', instructor:'উস্তাদ প্যানেল', durationBn:'৪ সপ্তাহ', durationEn:'4 weeks', type:'paid' }
];

const DUMMY_GOLDEN_CHAIN = [
  { nameBn:'রাসূলুল্লাহ ﷺ', nameEn:'Prophet Muhammad ﷺ' },
  { nameBn:'হযরত আবু বকর (রা.)', nameEn:'Abu Bakr (RA)' },
  { nameBn:'সালমান ফারসি (রা.)', nameEn:'Salman al-Farsi (RA)' },
  { nameBn:'কাসিম বিন মুহাম্মদ', nameEn:'Qasim ibn Muhammad' }
];

/* ---------- Renderers ---------- */

function rk_lang(){ return document.documentElement.getAttribute('data-lang') || 'bn'; }

function renderArticles(){
  const el = document.getElementById('articles-grid');
  if(!el) return;
  el.innerHTML = DUMMY_ARTICLES.map(function(a){
    return '<article class="card">' +
      '<div class="card-media"></div>' +
      '<div class="card-body">' +
        '<span class="card-cat" lang="bn">' + a.category + '</span>' +
        '<span class="card-cat" lang="en">' + a.categoryEn + '</span>' +
        '<h3 class="card-title" lang="bn">' + a.titleBn + '</h3>' +
        '<h3 class="card-title" lang="en">' + a.titleEn + '</h3>' +
        '<p class="card-excerpt" lang="bn">' + a.excerptBn + '</p>' +
        '<p class="card-excerpt" lang="en">' + a.excerptEn + '</p>' +
        '<div class="card-meta"><span>' + a.date + '</span><span lang="bn">বিস্তারিত পড়ুন →</span><span lang="en">Read more →</span></div>' +
      '</div>' +
    '</article>';
  }).join('');
}

function renderZikr(){
  const el = document.getElementById('zikr-grid');
  if(!el) return;
  el.innerHTML = DUMMY_ZIKR.map(function(z){
    return '<div class="piece-card">' +
      '<div class="piece-arabic">' + z.arabic + '</div>' +
      '<p class="piece-title" lang="bn">' + z.titleBn + '</p>' +
      '<p class="piece-title" lang="en">' + z.titleEn + '</p>' +
      '<span class="piece-count" lang="bn">' + z.countBn + '</span>' +
      '<span class="piece-count" lang="en">' + z.countEn + '</span>' +
    '</div>';
  }).join('');
}

function renderDua(){
  const el = document.getElementById('dua-grid');
  if(!el) return;
  el.innerHTML = DUMMY_DUA.map(function(d){
    return '<div class="piece-card">' +
      '<div class="piece-arabic">' + d.arabic + '</div>' +
      '<p class="piece-title" lang="bn">' + d.titleBn + '</p>' +
      '<p class="piece-title" lang="en">' + d.titleEn + '</p>' +
      '<p class="piece-sub" lang="bn">' + d.occasionBn + '</p>' +
      '<p class="piece-sub" lang="en">' + d.occasionEn + '</p>' +
    '</div>';
  }).join('');
}

function renderBooks(){
  const el = document.getElementById('books-grid');
  if(!el) return;
  el.innerHTML = DUMMY_BOOKS.map(function(b){
    return '<article class="card">' +
      '<div class="card-media"></div>' +
      '<div class="card-body">' +
        '<h3 class="card-title" lang="bn">' + b.titleBn + '</h3>' +
        '<h3 class="card-title" lang="en">' + b.titleEn + '</h3>' +
        '<p class="card-excerpt">' + b.author + '</p>' +
        '<div class="card-meta"><span lang="bn">বইটি দেখুন →</span><span lang="en">View book →</span></div>' +
      '</div>' +
    '</article>';
  }).join('');
}

function renderCourses(){
  const el = document.getElementById('courses-grid');
  if(!el) return;
  el.innerHTML = DUMMY_COURSES.map(function(c){
    const badge = c.type === 'free'
      ? '<span class="badge" lang="bn">ফ্রি</span><span class="badge" lang="en">Free</span>'
      : '<span class="badge paid" lang="bn">পেইড</span><span class="badge paid" lang="en">Paid</span>';
    return '<article class="card">' +
      '<div class="card-media"></div>' +
      '<div class="card-body">' +
        badge +
        '<h3 class="card-title" lang="bn">' + c.titleBn + '</h3>' +
        '<h3 class="card-title" lang="en">' + c.titleEn + '</h3>' +
        '<p class="card-excerpt">' + c.instructor + ' \u2014 <span lang="bn">' + c.durationBn + '</span><span lang="en">' + c.durationEn + '</span></p>' +
        '<div class="card-meta"><span lang="bn">কোর্সটি দেখুন →</span><span lang="en">View course →</span></div>' +
      '</div>' +
    '</article>';
  }).join('');
}

function renderGoldenChain(){
  const el = document.getElementById('golden-chain-preview');
  if(!el) return;
  el.innerHTML = DUMMY_GOLDEN_CHAIN.map(function(p, i){
    return '<div class="chain-node">' +
      '<div class="chain-avatar">' + (i+1) + '</div>' +
      '<p class="chain-name" lang="bn">' + p.nameBn + '</p>' +
      '<p class="chain-name" lang="en">' + p.nameEn + '</p>' +
    '</div>';
  }).join('');
}

document.addEventListener('DOMContentLoaded', function(){
  renderArticles();
  renderZikr();
  renderDua();
  renderBooks();
  renderCourses();
  renderGoldenChain();
});

/* Expose dummy data + language helper globally for pages like search.html */
window.DUMMY_ARTICLES = DUMMY_ARTICLES;
window.DUMMY_BOOKS = DUMMY_BOOKS;
window.DUMMY_COURSES = DUMMY_COURSES;
window.DUMMY_ZIKR = DUMMY_ZIKR;
window.DUMMY_DUA = DUMMY_DUA;
window.rk_lang = rk_lang;
