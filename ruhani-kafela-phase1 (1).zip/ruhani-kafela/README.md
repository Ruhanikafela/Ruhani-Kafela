# রুহানি কাফেলা / Ruhani Kafela — Phase 1

এটি Phase 1: সম্পূর্ণ স্ট্যাটিক ফ্রন্টএন্ড, ডামি/নমুনা কনটেন্ট সহ। এখনো কোনো ব্যাকএন্ড (Google Sheets/Apps Script) যুক্ত হয়নি — সেটি Phase 2-তে হবে।

## ফোল্ডার গঠন

```
ruhani-kafela/
├── index.html            হোমপেজ
├── articles.html / article.html
├── books.html / book.html
├── courses.html / course.html
├── zikr.html / meditation.html
├── dua.html / amal.html
├── golden-chain.html / ahlul-bayt.html
├── about.html / login.html / profile.html / search.html
├── css/
│   ├── style.css         মূল ডিজাইন সিস্টেম (রং, ফন্ট, কম্পোনেন্ট)
│   └── responsive.css    মোবাইল/ট্যাবলেট স্টাইল
├── js/
│   ├── language.js       বাংলা/ইংরেজি টগল (localStorage-এ সংরক্ষিত)
│   └── app.js            ডামি কনটেন্ট + রেন্ডারিং লজিক
├── assets/logo/          লোগো ও আইকন (SVG)
├── robots.txt
└── sitemap.xml
```

## GitHub Pages-এ ডিপ্লয় করবেন যেভাবে

1. github.com-এ একটি নতুন public রিপোজিটরি বানান (যেমন `ruhani-kafela`)।
2. এই পুরো ফোল্ডারের সব ফাইল/সাবফোল্ডার সেই রিপোতে আপলোড করুন (GitHub-এর "Add file → Upload files" ব্যবহার করতে পারেন)।
3. রিপোর Settings → Pages-এ যান।
4. Branch হিসেবে `main` এবং folder `/ (root)` নির্বাচন করে Save করুন।
5. কিছুক্ষণ পর একটি URL পাবেন, যেমন: `https://yourname.github.io/ruhani-kafela/`

## এখন কী পরিবর্তন করবেন (কোড না ছুঁয়ে যতটা সম্ভব)

- **টেক্সট/কনটেন্ট বদলাতে**: `js/app.js` ফাইলের উপরের দিকে `DUMMY_ARTICLES`, `DUMMY_ZIKR`, `DUMMY_DUA`, `DUMMY_BOOKS`, `DUMMY_COURSES`, `DUMMY_GOLDEN_CHAIN` — এই তালিকাগুলোতে আপনার নিজের কনটেন্ট বসাতে পারেন (Phase 2-তে এগুলো Admin Panel দিয়ে প্রতিস্থাপিত হবে)।
- **লোগো বদলাতে**: `assets/logo/logo.svg` ও `icon.svg` ফাইল পরিবর্তন করুন, অথবা PNG/JPG লোগো দিয়ে প্রতিস্থাপন করে `index.html`-এ (ও অন্যান্য পেজে) img ট্যাগের src বদলে দিন।
- **রং বদলাতে**: `css/style.css`-এর একদম উপরে `:root { --green-primary: ... }` অংশে হেক্স কোডগুলো বদলান — পুরো সাইটে প্রতিফলিত হবে।

## এখনো যা বাকি (পরবর্তী ফেজ)

- Phase 2: Google Sheets ডেটাবেস + Apps Script API + `admin.html` অ্যাডমিন প্যানেল
- Phase 3: OTP লগইন, কমেন্ট মডারেশন
- Phase 4: পেইড কোর্স, পেমেন্ট ইন্টিগ্রেশন
